﻿namespace GeometricFigureHandler
{
    public abstract class Shape2D : Shape
    {
        public abstract float Circumference { get; }
    }
}