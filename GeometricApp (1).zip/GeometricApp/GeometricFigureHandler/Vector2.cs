﻿namespace GeometricFigureHandler
{
    public class Vector2
    {
        public float X { get; set; }
        public float Y { get; set; }
    }
}